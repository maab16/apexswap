export const API_ENDPOINTS = {
  PRODUCTS: '/products',
  CATEGORIES: '/categories',
  SHOPS: '/shops',
  ORDERS: '/orders',
  USERS: '/users',
  LOGIN: '/token',
  SETTINGS: '/settings',
};
