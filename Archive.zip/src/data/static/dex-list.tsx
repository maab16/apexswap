export const dexList = [
  {
    address: '0x623DC9E82F055471B7675503e8deF05A35EBeA19',
    dex: 'TraderJoe'
  },
  {
    address: '0xeE57D82AA7c1f6Edb1aa63219828A55b1CAC2786',
    dex: 'PangolinSwap'
  },
  {
    address: '0x1b013c840f4b8BFa1cEaa7dd5f31d1f234C56A54',
    dex: 'SushiSwap'
  },
  {
    address: '0x4c90a08eab5DBAD079Abc165C29c1A32dDEf2beC',
    dex: 'ElkFinance'
  },
  {
    address: '0x011A8ab37D343B1A263f23642A92Fa0907C40550',
    dex: 'KyberDmm'
  },
  {
    address: '0x9cef6314A4a9Cc6D1DC5099411Bf3Dd3d3c5C170',
    dex: 'Platypus'
  },
  {
    address: '0xB6905101ef7E2c294058a29E89eb83e0f2866303',
    dex: 'GMX'
  },
  {
    address: '0x623DC9E82F055471B7675503e8deF05A35EBeA19', //trader joe
    dex: 'LydiaFinance'
  },
  {
    address: '0x9cef6314A4a9Cc6D1DC5099411Bf3Dd3d3c5C170', //Platypus
    dex: 'WooFi'
  },
  {
    address: '0x623DC9E82F055471B7675503e8deF05A35EBeA19', //Platypus
    dex: 'UniswapForkOptimized'
  },
];
