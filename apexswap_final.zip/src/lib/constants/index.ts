export const CONSTANT_VALUE = '';
